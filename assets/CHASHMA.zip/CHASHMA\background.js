/* CHASHMA — background service worker
   On the keyboard command (Ctrl/Cmd+Shift+S), tell the active tab's content
   script to toggle the magnifier. No screenshots, no data — the content script
   does everything locally with the page DOM. */
chrome.commands.onCommand.addListener((command) => {
  if (command !== 'search-current-screen') return;
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab?.id) return;
    chrome.tabs.sendMessage(tab.id, { type: 'CHASHMA_TOGGLE' });
  });
});
