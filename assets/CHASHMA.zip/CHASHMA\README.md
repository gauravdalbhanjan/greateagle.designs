# CHASMA
**Keyboard shortcut that magnifies the search — so you always know exactly where you are.**

---

## What it does

Every time you land on a page with a search field, finding it means either clicking around or tabbing blindly. CHASMA solves that in one keystroke:

- Press **Ctrl + Shift + S** (Windows / Linux) or **⌘ + Shift + S** (Mac)
- A glowing magnifying-glass indicator appears over the active search field instantly
- If there are multiple search inputs, **Tab** cycles through them — a counter badge shows which one you're on
- Press **Esc** (or click elsewhere) to dismiss

No setup. No sign-in. No data collected. It runs entirely on the page you're looking at.

---

## Shortcuts

| Action | Windows / Linux | Mac |
|---|---|---|
| Activate CHASMA | `Ctrl + Shift + S` | `⌘ + Shift + S` |
| Next search field | `Tab` | `Tab` |
| Previous search field | `Shift + Tab` | `Shift + Tab` |
| Dismiss | `Esc` | `Esc` |

You can change the shortcut any time at `chrome://extensions/shortcuts`.

---

## Visual indicator

When CHASMA activates, a red-outlined overlay appears exactly over the focused input:

- **Horizontal size:** input width + **8px padding** on each side — always fits the field
- **Vertical size:** flexible — matches the input's own height
- A **magnifying-glass icon** sits 2–3pt above the input's font size, flush to the right edge
- If multiple search fields exist, a small **n / total** badge appears above the overlay so you never lose your place

---

## Privacy

CHASMA is 100% local. It:
- Uses only the `activeTab` permission (only runs on the tab you're on, when you press the shortcut)
- Collects **zero** data
- Makes **no network requests**
- Stores **nothing**

---

## Installation

### From the Chrome Web Store *(coming soon)*
Search "CHASMA" and click Add to Chrome.

### Developer / local install
1. Download or clone this repository
2. Open Chrome → `chrome://extensions`
3. Enable **Developer mode** (top-right toggle)
4. Click **Load unpacked** → select the `chasma` folder
5. Press **Ctrl + Shift + S** on any page to test

---

## Built by
[Gaurav Dalbhanjan](https://greateagledesigns.com) — designer with an engineer's brain.
