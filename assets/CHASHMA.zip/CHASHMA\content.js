/* CHASHMA — content script (live DOM magnifier)
   ─────────────────────────────────────────────────────────────────────
   Ctrl/Cmd+Shift+S (CHASHMA_TOGGLE from background.js):
     • Orange outline marks the focused search field (you-are-here).
     • A GREEN magnified box floats ABOVE the field — or BELOW if there isn't
       enough room above (based on viewport space) — showing its text ~2.3×.
     • Tab / Shift+Tab / A move between fields. Esc dismisses.
   100% local: no screenshots, no network, no data stored.
   ─────────────────────────────────────────────────────────────────────*/
(function () {
  'use strict';

  const ORANGE = '#ff2a00';
  const GREEN  = '#00c853';
  const MAG    = 2.3;    // magnification factor
  const H_PAD  = 8;      // horizontal padding each side of the field
  const GAP    = 12;     // gap between field and the green box

  let outline = null, lens = null, mirror = null, countEl = null;
  let targets = [], idx = 0, active = false, raf = null;

  function getTargets() {
    const sel = [
      'input[type="search"]', 'input[type="text"]',
      'input[placeholder*="search" i]', 'input[placeholder*="find" i]',
      'input[aria-label*="search" i]', '[role="searchbox"]', '[role="combobox"]'
    ].join(',');
    return Array.from(document.querySelectorAll(sel)).filter((el) => {
      if (el.disabled || el.readOnly) return false;
      const s = getComputedStyle(el);
      if (s.display === 'none' || s.visibility === 'hidden' || s.opacity === '0') return false;
      const r = el.getBoundingClientRect();
      return r.width > 4 && r.height > 4;
    });
  }

  function build() {
    if (lens) return;

    // Orange outline on the field.
    outline = document.createElement('div');
    outline.id = 'chashma-outline';
    outline.style.cssText = [
      'position:fixed', 'z-index:2147483646', 'pointer-events:none', 'box-sizing:border-box',
      'border:1.6px solid ' + ORANGE, 'border-radius:6px', 'background:rgba(255,42,0,0.06)',
      'box-shadow:0 0 0 3px rgba(255,42,0,0.18), 0 4px 20px rgba(255,42,0,0.22)'
    ].join(';');
    document.body.appendChild(outline);

    // Green magnified box.
    lens = document.createElement('div');
    lens.id = 'chashma-lens';
    lens.style.cssText = [
      'position:fixed', 'z-index:2147483647', 'pointer-events:none', 'overflow:hidden', 'box-sizing:border-box',
      'border:3px solid ' + GREEN, 'border-radius:8px', 'background:#fff',
      'box-shadow:0 0 0 3px rgba(0,200,83,0.22), 0 10px 32px rgba(0,0,0,0.28)'
    ].join(';');

    mirror = document.createElement('div');
    mirror.style.cssText = 'position:absolute;top:0;left:0;transform-origin:0 0;';
    lens.appendChild(mirror);

    const sheen = document.createElement('div');
    sheen.style.cssText =
      'position:absolute;inset:0;pointer-events:none;border-radius:inherit;z-index:4;' +
      'background:radial-gradient(130% 80% at 26% 10%, rgba(255,255,255,0.45) 0%, rgba(255,255,255,0) 55%);';
    lens.appendChild(sheen);

    const badge = document.createElement('span');
    badge.style.cssText = 'position:absolute;top:50%;right:8px;transform:translateY(-50%);z-index:5;';
    badge.innerHTML =
      '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="' + GREEN + '" stroke-width="2.6" stroke-linecap="round"><circle cx="10.5" cy="10.5" r="6.5"/><line x1="15.5" y1="15.5" x2="21" y2="21"/></svg>';
    lens.appendChild(badge);

    countEl = document.createElement('span');
    countEl.style.cssText =
      'position:absolute;top:-11px;left:50%;transform:translateX(-50%);z-index:5;' +
      'background:' + GREEN + ';color:#fff;font:700 10px/1 system-ui,sans-serif;' +
      'letter-spacing:.04em;padding:2px 7px;border-radius:100px;';
    lens.appendChild(countEl);

    document.body.appendChild(lens);
  }

  function buildMirror(el) {
    const cs = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    const hasVal = !!el.value;
    const field = document.createElement('div');
    field.style.cssText =
      'box-sizing:border-box;width:' + r.width + 'px;height:' + r.height + 'px;' +
      'display:flex;align-items:center;' +
      'font-family:' + cs.fontFamily + ';font-weight:' + cs.fontWeight + ';font-size:' + cs.fontSize + ';' +
      'padding:' + cs.paddingTop + ' ' + cs.paddingRight + ' ' + cs.paddingBottom + ' ' + cs.paddingLeft + ';' +
      'background:#fff;color:' + (hasVal ? cs.color : '#9a9a9a') + ';' +
      'white-space:nowrap;overflow:hidden;';
    field.textContent = hasVal ? el.value : (el.placeholder || '');
    mirror.innerHTML = '';
    mirror.appendChild(field);
    mirror._field = field;
    mirror._fieldH = r.height;
  }

  function syncInputs() {
    if (!mirror || !mirror._field || !targets[idx]) return;
    const el = targets[idx];
    const hasVal = !!el.value;
    const cs = getComputedStyle(el);
    mirror._field.textContent = hasVal ? el.value : (el.placeholder || '');
    mirror._field.style.color = hasVal ? cs.color : '#9a9a9a';
  }

  function layout(el) {
    const r = el.getBoundingClientRect();

    // 1. Orange outline exactly on the field.
    outline.style.left   = r.left + 'px';
    outline.style.top    = r.top + 'px';
    outline.style.width  = r.width + 'px';
    outline.style.height = r.height + 'px';

    // 2. Green box dimensions.
    const W = r.width + H_PAD * 2;
    const H = Math.round(r.height * MAG);          // taller so the zoom has room
    let left = r.left - H_PAD;
    left = Math.max(4, Math.min(left, window.innerWidth - W - 4));

    // 3. Above vs below based on viewport space.
    const needed = H + GAP + 8;
    const placeAbove = r.top >= needed || r.top >= (window.innerHeight - r.bottom);
    let top = placeAbove ? (r.top - H - GAP) : (r.bottom + GAP);
    top = Math.max(4, Math.min(top, window.innerHeight - H - 4));

    lens.style.width = W + 'px';
    lens.style.height = H + 'px';
    lens.style.left = left + 'px';
    lens.style.top = top + 'px';

    // 4. Magnify: left-align the start of the text, vertically centre.
    const fh = mirror._fieldH || r.height;
    const ty = (H - fh * MAG) / 2;
    mirror.style.transform = 'translate(0px,' + ty + 'px) scale(' + MAG + ')';

    if (targets.length > 1) { countEl.style.display = ''; countEl.textContent = (idx + 1) + ' / ' + targets.length; }
    else countEl.style.display = 'none';
  }

  function focusTarget(i) {
    if (!targets.length) return;
    idx = ((i % targets.length) + targets.length) % targets.length;
    const el = targets[idx];
    el.focus({ preventScroll: true });
    el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    buildMirror(el);
    layout(el);
  }

  function tick() {
    if (!active) return;
    syncInputs();
    if (targets[idx]) layout(targets[idx]);
    raf = requestAnimationFrame(tick);
  }

  function activate() {
    targets = getTargets();
    if (!targets.length) { toast('🔍 No search field found on this page'); return; }
    build();
    lens.style.display = ''; outline.style.display = '';
    active = true;
    const fi = targets.indexOf(document.activeElement);
    idx = fi !== -1 ? fi : 0;
    focusTarget(idx);
    raf = requestAnimationFrame(tick);
    document.addEventListener('keydown', onKey, true);
  }

  function dismiss() {
    active = false;
    if (raf) cancelAnimationFrame(raf);
    if (lens) lens.style.display = 'none';
    if (outline) outline.style.display = 'none';
    document.removeEventListener('keydown', onKey, true);
  }

  function onKey(e) {
    if (e.key === 'Escape') { e.preventDefault(); dismiss(); return; }
    if (e.key === 'Tab')    { e.preventDefault(); focusTarget(idx + (e.shiftKey ? -1 : 1)); return; }
    if ((e.key === 'a' || e.key === 'A') && document.activeElement !== targets[idx]) {
      e.preventDefault(); focusTarget(idx - 1);
    }
  }

  function toast(text) {
    const t = document.createElement('div');
    t.textContent = text;
    t.style.cssText =
      'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:2147483647;' +
      'background:#1a0a08;color:#fff;font:600 13px system-ui,sans-serif;padding:10px 20px;' +
      'border-radius:100px;border:1px solid rgba(255,42,0,0.4);box-shadow:0 4px 20px rgba(0,0,0,0.4);';
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 1800);
  }

  // Toggle from the Ctrl/Cmd+Shift+S command.
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type !== 'CHASHMA_TOGGLE') return;
    active ? dismiss() : activate();
  });
})();
